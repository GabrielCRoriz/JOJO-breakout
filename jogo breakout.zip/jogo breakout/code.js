var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var raquete= createSprite(200,320,80,10);
var ball = createSprite(200,300,20,20);
var gameState = "inicio";
var grupotijolos = createGroup();
var tijolo;
//DECLARAR VARIAVELvar
var score =0;

function quebrartijolo(ball,tijolo) {
    tijolo.remove();
    score+=1;
    
  }
tijolos(65,"yellow");
tijolos(65+29,"pink");
tijolos(65+29+29,"purple");
tijolos(65+29+29+29,"deepskyblue");

function draw() {
//chave no lugar errado
  background("white");
  drawSprites();
  text("score:"+score,200,10);
  fill("yellow");
  textSize(20);
  
  if(gameState == "inicio"){
  textSize(18);
  fill("black");
  text("Clique na bola para começar",100,200);
  moveball();
  }
 
  else if (gameState == "play"){
     //chamar o stado do jogo play aqui, variavel de grupo no plural
    ball.bounceOff(grupotijolos, quebrartijolo);
    
    //adicionar condições para mover a raquete aqui
    if(keyDown("right")){
    raquete.x = raquete.x+4;
    }
    if(keyDown("left")){
    raquete.x = raquete.x-4;
    }
    if (score==24){
      gamestate="end";
      text("You Win!!!", 155, 200);
    }
    if (ball.y > 400){
    gamestate="end";
    text("Clique para reiniciar", 155, 200);
    }
    if ("gamestate"=="end"){
      ball.x=200;
      ball.y=252;
      ball.setVelocity(0,0);
    }
  }
    
 
  moveball();
  createEdgeSprites();
  ball.bounceOff(raquete);
  ball.bounceOff(topEdge);
  ball.bounceOff(leftEdge);
  ball.bounceOff(rightEdge);
  raquete.bounceOff(leftEdge);
  raquete.bounceOff(rightEdge);
  }
  
function tijolos(y,color) {
for (var pose = 0; pose < 6; pose++){
  tijolo= createSprite(65+54*pose, y, 50, 25);
  tijolo.shapeColor = color;
  grupotijolos.add(tijolo);
}
  
}
function moveball(){
  if (mousePressedOver(ball)) {
    ball.velocityX = -2;
    ball.velocityY = +5;
    gameState="play";
  }}
  
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
